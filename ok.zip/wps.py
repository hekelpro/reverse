import requests as r, os, platform, re, string
from bs4 import BeautifulSoup as par
from random import choice
from concurrent.futures import ThreadPoolExecutor as td
clear = lambda: os.system("clear") if "linux" in platform.system().lower() else os.system("cls")

def randPass(digit):
	asc = string.ascii_lowercase + string.digits
	rand = "".join([choice(asc) for x in range(digit)])
	return rand

def wp_login(url, u, p):
	#-> set session cookie
	sesi = r.Session()
	sesi.headers.update({"User-Agent": "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36"})

	#-> check response
	try:
		cek = par(sesi.get(url + "/wp-login.php").text, "html.parser")
		forms = cek.find("form", {"method": "post"})
		payload = {}
		for inp in forms.find_all("input"):
			payload.update({inp.get("name"): inp.get("value")})
		payload.update({"log": u, "pwd": p})
		posted = sesi.post(forms.find("action"), data=payload, allow_redirects=True).text
		if posted in ["adminmenumain", "wpadminbar", "menu-dashboard"]:
			print("  _> login success u: %s p: %s " % (u, p))
		else:
			print("  _> login failed, wrong user/pass")
	except r.exceptions.ConnectionError:
		print("  _> login failed, wrong user/pass")

def wp_install(url, mail):
	#-> set session cookie or data
	password = randPass(8)
	sesi = r.Session()
	sesi.headers.update({"User-Agent": "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36"})

	#-> check content or response
	try:
		cek = sesi.get(url + "/wp-admin/install.php", allow_redirects=True).text
		if "admin_password" in str(cek) or "language-continue" in str(cek): #or "id_ID" in str(cek):
			open("yes.txt", "a+").write(url+"/wp-admin/install.php\n")
			print("\x1b[1;92m  _> tester: "+url+"/wp-admin/install.php")
		else:
			print("\x1b[1;91m  _> tester: "+url+"/wp-admin/install.php")
	except:
		print("\x1b[1;91m  _> tester: "+url+"/wp-admin/install.php")

clear()
red = open("ok", "r").read().strip().split("\n")
with td(max_workers=20) as sub:
	for url in red:
		sub.submit(wp_install, url, True)
