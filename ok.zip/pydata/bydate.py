import requests as r

def writer(name, content):
	try:
		if content in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content.strip().replace("\n","")+"\n")
	except FileNotFoundError:
		open(name, "a+").write(content.strip().replace("\n","")+"\n")


def execution(todate, month, year, nameFile):
	nc = []
	for run in range(int(todate)+1):
		if run < 10:
			oy = "0"+str(run)
		else:
			oy = str(run)
		cek = r.get("https://www.desktopcatcher.com/wp-content/plugins/domaingrab/download.php?date=%s-%s-%s" % (month, oy, year)).text.strip().split("\n")
		if len(cek) <= 1:
			pass
		else:
			for coy in cek:
				writer(nameFile, "http://"+coy)
			nc.append(coy)
	if len(nc) != 0:
		return True
	else:
		return False

#if execution("15","10","2022","ok"):
#	print("selesai")
