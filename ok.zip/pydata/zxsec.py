import requests as r, re
from bs4 import BeautifulSoup as par

def writer(name, content):
	try:
		if content in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content.strip().replace("\n","")+"\n")
	except FileNotFoundError:
		open(name, "a+").write(content.strip().replace("\n","")+"\n")


def archive(nameFile):
	page = 1
	agent  = {"user-agent": "chrome"}
	url = "https://zone-xsec.com" + "/archive/page=%s" % (page)
	while True:
		cek = par(r.get(url, headers=agent).text, "html.parser")
		tbody = cek.find("tbody")
		for tr in tbody.find_all("tr"):
			ref = "".join(re.findall("\<td>(.*?)<\/td>\n.*?Show", str(tr)))
			writer(nameFile, "http://"+ref.split("/")[0].rstrip("."))
		if "pagination pagination-sm" in str(cek):
			page += 1
			url = "https://zone-xsec.com" + "/archive/page=%s" % (page)
			continue
		else:
			break
	return True

def special(nameFile):
	page = 1
	agent  = {"user-agent": "chrome"}
	url = "https://zone-xsec.com" + "/special/page=%s" % (page)
	while True:
		cek = par(r.get(url, headers=agent).text, "html.parser")
		tbody = cek.find("tbody")
		for tr in tbody.find_all("tr"):
			ref = "".join(re.findall("\<td>(.*?)<\/td>\n.*?Show", str(tr)))
			writer(nameFile, "http://"+ref.split("/")[0].rstrip("."))
		if "pagination pagination-sm" in str(cek):
			page += 1
			url = "https://zone-xsec.com" + "/special/page=%s" % (page)
			continue
		else:
			break
	return True

def onhold(nameFile):
	page = 1
	agent  = {"user-agent": "chrome"}
	url = "https://zone-xsec.com" + "/onhold/page=%s" % (page)
	while True:
		cek = par(r.get(url, headers=agent).text, "html.parser")
		tbody = cek.find("tbody")
		for tr in tbody.find_all("tr"):
			ref = "".join(re.findall("\<td>(.*?)<\/td>\n.*?Show", str(tr)))
			writer(nameFile, "http://"+ref.split("/")[0].rstrip("."))
		if "pagination pagination-sm" in str(cek):
			page += 1
			url = "https://zone-xsec.com" + "/onhold/page=%s" % (page)
			continue
		else:
			break
	return True

#archive("ok")
