import requests as ex, re
from json import loads
from urllib.parse import quote
from concurrent.futures import ThreadPoolExecutor as Exec
r = ex.Session()
reg = lambda code: re.findall("(https?://.*?)/.*?", str(code))[0]

def writer(name, content):
	try:
		if content in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content.strip().replace("\n","")+"\n")
	except FileNotFoundError:
		open(name, "a+").write(content.strip().replace("\n","")+"\n")

def urlscan(query, nameFile):
	query = quote("page.url:\""+query+"\"")
	cek = r.get("https://urlscan.io/api/v1/search/?q="+query).json()["results"]
	bungkus = []
	for rest in cek:
		apex = reg(rest["page"]["url"])
		sorts = rest["sort"]

		bungkus.append("%s,%s" % (sorts[0], sorts[1]))
		writer(nameFile, apex)
	if len(bungkus) == 0:
		return True
	else:
		with Exec(max_workers=20) as sub:
			for yy in bungkus:
				sub.submit(ngenskuy, yy, nameFile, query)
		return True

def ngenskuy(affh, nameFile, query):
	gets = r.get("https://urlscan.io/api/v1/search/?q="+query+"&search_after=%s" % (affh)).json()["results"]
	for rest in gets:
		apex = reg(rest["page"]["url"])
		writer(nameFile, apex)
