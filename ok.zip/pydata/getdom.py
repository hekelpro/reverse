import requests as r, re
from bs4 import BeautifulSoup as par
priaIdaman = []

def writer(name, content):
	try:
		if content in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content.strip().replace("\n","")+"\n")
	except FileNotFoundError:
		open(name, "a+").write(content.strip().replace("\n","")+"\n")

def getr(nameFile):
	for x in range(50499):
		cek = r.get("https://whoisdatacenter.com/free-database/%s" % (x), headers={"user-agent": "chrome"}).text
		ok = re.findall("Domain\sName.*?<a.*?img.*?/span>(.*?)<.*?", str(cek))
		for yx in ok:
			writer(nameFile, "http://"+yx.strip())
		priaIdaman.append(ok)
	if len(priaIdaman) != 0:
		return True
	else:
		return False


# getr("ok")
