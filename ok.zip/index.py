import requests as r, os, platform, re, cloudscraper
from json import loads
from random import choice
from pydata.bydate import *
from pydata.getdom import *
from pydata.zxsec import *
from pydata.urlscan import *
from time import sleep
from concurrent.futures import ThreadPoolExecutor as pol
from threading import Thread as td

#-> execution from one line
clear = lambda: os.system("clear") if platform.system().lower() == "linux" else os.system("cls")
openFile = lambda file: open(file, "r").read().strip().split("\n")
sc = cloudscraper.create_scraper()

def writer(name, content):
	try:
		if content in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content.strip().replace("\n","")+"\n")
	except FileNotFoundError:
		open(name, "a+").write(content.strip().replace("\n","")+"\n")


def saved():
	while True:
		fln = input("?: save in file: ")
		try:
			openFile(fln)
			ask = input("!: File ini sudah ada\n?: apakah hasilnya mau digabung dengan file ini?\n  >> ya/tidak (Y/T): ")
			if ask in list("Yy"):
				break
			elif ask in list("Tt"):
				continue
			else:
				continue
		except FileNotFoundError:
			break
	return fln

def ceks():
	fileip = input("?: File list url: ")
	while True:
		try:
			check = open(fileip, "r").read().strip().split("\n")
		except FileNotFoundError:
			print("!: File not found")
			fileip = input("?: File list url: ")
			continue
		break
	return check

def reverse(query, nameFile):
	agent = {"User-Agent": "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36"}
	check = sc.get("https://rapiddns.io/sameip/%s#result" % (query), headers=agent).text

	reg = re.findall("<td>(.*?)</td>\n<td.*?a.*?title.*?", str(check))
	if len(reg) == 0:
		print("  :> \x1b[1;95m"+query+"\x1b[1;00m > \x1b[1;92m0\x1b[1;00m site found! ")
	else:
		parser = par(check, "html.parser")
		try:
			blog = parser.findAll("a", {"class":"page-link"})[-2]
			if blog is not None:
				page = int(blog.text)
			elif blog is None:
				page = 1
			else:
				page = 1
		except:
			page = 1
		for x in range(page+1):
			ch = sc.get("https://rapiddns.io/sameip/%s?page=%s&t=None#result" % (query, x), headers=agent).text
			reg = re.findall("<td>(.*?)</td>\n<td.*?a.*?title.*?", str(ch))
			if len(reg) == 0:
				break
			else:
				for wr in reg:
					writer(nameFile, "http://"+wr)
				print("  :> \x1b[1;95m"+query+"?page="+str(x)+"\x1b[1;00m > \x1b[1;92m"+str(len(reg))+"\x1b[1;00m site found! ")
#reverse("academycursosoficial.com",True)
#exit()

def grabber(nameFile, date, query):
	urlscan(query, nameFile)
	getr(nameFile)
	archive(nameFile)
	special(nameFile)
	onhold(nameFile)
	ds = date.split("-")
	execution(ds[0], ds[1], ds[2], nameFile)

def subdomain(subdo, file):
	subdo = subdo.replace("http://","").replace("https://","").split("/")[0]
	cek = r.get("https://apiwhats.my.id/subdomain?subdo="+subdo)
	try:
		for x in cek.json()["result"]:
			writer(file, "http://%s" % (x))
		print("  :> \x1b[1;95m"+subdo+"\x1b[1;00m > \x1b[1;92m"+str(len(cek.json()["result"]))+"\x1b[1;00m subdomain found! ")
	except:
		writer(file, "http://%s" % (subdo))
		print("  :> \x1b[1;95m"+subdo+"\x1b[1;00m >\x1b[1;91m "+file+"\x1b[1;00m, domain not found!")

def subdo(type=None):
	if type is None:
		exit("×: Wrong type\n")
	else:
		if type == "s":
			trg = input("?: domain: ")
			sv = saved()
			print("")
			subdomain(trg, sv)
			print("\n✓: Process done\n")
		if type == "m":
			trg = ceks()
			sv  = saved()
			print("")
			for ya in trg:
				subdomain(ya, sv)
			print("\n✓: Process done\n")

def rev(type=None):
	if type is None:
		exit("×: Wrong type\n")
	else:
		if type == "s":
			trg = input("?: ip/domain: ")
			sv  = saved()
			print("")
			with pol(max_workers=20) as sub:
				sub.submit(reverse, trg, sv)
			print("\n✓: Process done\n")
		if type == "m":
			trg = ceks()
			sv  = saved()
			print("")
			#with pol(max_workers=10) as sub:
			for ya in trg:
				ya = ya.replace("https://","").replace("http://","").split("/")[0]
				reverse(ya, sv)
				#print(ya)
			print("\n✓: Process done\n")

def start_menu():
	clear()
	print("""
?:: Choose menu:
	1. Single reverse ip/domain
	2. Multi reverse ip/domain
	3. Single subdomain finder
	4. Multi subdomain finder
	5. grabber domain
	""")
	inp = input("?:: choose: ")
	while not inp.isdigit() or inp == "":
		inp = input("?:: choose: ")
	if inp == "1":
		rev(type="s")
	elif inp == "2":
		rev(type="m")
	elif inp == "3":
		subdo(type="s")
	elif inp == "4":
		subdo(type="m")
	elif inp == "5":
		month = input("\n?: bulan: ")
		dates = input("?: sampai tanggal: ")
		year = input("?: tahun: ")
		query = input("?: query: ")
		oks = dates+"-"+month+"-"+year
		nms = saved()
		t = td(target=grabber, args=(nms, oks, query,))
		t.start()
		while t.is_alive():
			for x in list("-\|/"):
				print("\r"+x+": sedang mwngumpulkan, tetap pantau filenya.. ", end="")
				sleep(0.3)
	else:
		exit("×: wrong choice\n")

if __name__=="__main__":
	start_menu()
