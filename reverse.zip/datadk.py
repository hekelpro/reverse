import sys, re
file =open(raw_input("file : ")).read()
ou =raw_input('out  : ')
k = ['d', 'k']
s = re.findall(r'(?si).*?1 \(d\)', file)
for i in range(2):
    c = re.findall(r'(?si)load_const.*?\((\d*)\)', s[i])
    if i == 1:
        c = c[2:]
    c = [int(j) for j in c]
    with open(ou, 'a') as f:
        f.write(k[i] + '=' + str(c) + '\n')